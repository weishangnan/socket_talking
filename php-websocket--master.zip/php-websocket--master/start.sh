#!/bin/bash
php ./socketServer.php &